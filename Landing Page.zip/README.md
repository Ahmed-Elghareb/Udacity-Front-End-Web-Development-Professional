# Landing Page Project

## Table of Contents

* Intro 
* Adding Anchors
* Styling Anchors
* Adding Sections
* Testing Three Sections Above
* Adding EventListener

## Intro

In this project I have been modifying a Landing Page project dynamically in order to meet some design requirements of the Landing Page, which is resposible for viewing content dynamically. In general, the project is based on JS programming which interacs with HTML and CSS to be able to create, modify, and remove content of a web page.


## Adding anchors

By iterating over listed sections of the "main" tag, I magaed to create anchors and list them by order on the navigation bar.


## Styling Anchors

I used concepts studied to modify content through JavaScript to be able to modify the anchors on the navigation bar so that they are more good looking and interactive. 


## Adding Sections 

I modified the code so that it accepts any added sections and adding new anchors interactively with the new sections.


## Testing Three Sections Above

Started adding sections with new heading and id and observed the results which came to be posotive.


## Adding EventListener

This part was not quite simple. It needed much of a thought to decided how to pick the correct section to be the active one, and the largest in terms of a function wrote. The code looks for three cases at which the section could be while viewing it on screen, and though the three cases, it matches the case of the section relative to the screen coordinates, and decides if that section is to be set active or not, if not it removes its class. 


