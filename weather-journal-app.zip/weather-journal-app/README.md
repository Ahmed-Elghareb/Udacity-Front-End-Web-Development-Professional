# Weather-Journal App Project

## Overview
This project requires is based on creating an asynchronous web app that uses Web API and user data to dynamically update the UI. I Implemented client side and server side code, in addition to web API in order to complete the cycle of interactions between them.  

## Content
### 1. Server Side Code
### 2. Client Side Code

## 1. Server Side Code
Initiated an "app" instance from library "express", established the middleware libraries and functions, set routes for get and post requests with the client side, and established a listening function for the server to use. 


## 2. Client Side Code
Set API credentials, made get and post reuests, used the data from the end-point and API to update the UI dynamically gien the input data.

